package com.avinash.pixogram.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.avinash.pixogram.model.User;
import com.avinash.pixogram.repo.UserRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class UserController {

	@Autowired
	UserRepository repository;

	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/users")
	public List<User> getAllUsers() {
		System.out.println("Get all Users...");
		return (List<User>) repository.findAll();
	}

	@PostMapping("/create")
	public User postCustomer(@RequestBody User user) {
		System.out.println("Adding new User");
		User _user = repository.save(new User(user.getName(), user.getPassword(), user.getEmail()));
		return _user;
	}

//	@CrossOrigin(origins = "http://localhost:4200")
//	@PostMapping(value = "/user/create")
//	public User postCustomer(@RequestBody User user) {
//
//		User _user = repository.save(new User(user.getId(), user.getName()));
//		return _user;
//	}

}
